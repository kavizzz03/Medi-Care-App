Google App Engine
=================

Google's documentation is
[here](https://developers.google.com/appengine/docs/java/mail).

Note that GAE limits the headers and attachment types you can use,
as described in the
[Google Cloud documentation](https://cloud.google.com/appengine/docs/standard/java/mail/mail-with-headers-attachments).
