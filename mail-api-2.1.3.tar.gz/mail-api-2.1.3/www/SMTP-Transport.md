SMTP Transport
==============

The only Transport (for sending mail) provided with Jakarta Mail uses the
SMTP protocol. The primary documentation for the SMTP Transport is in
the javadocs for the
[com.sun.mail.smtp package](docs/api/com/sun/mail/smtp/package-summary.html).
Be sure to read the package level javadocs, which describe the
properties you can set, as well as the javadocs for the individual
classes in the package.

This page is currently a placeholder for more information about the
SMTP Transport.
