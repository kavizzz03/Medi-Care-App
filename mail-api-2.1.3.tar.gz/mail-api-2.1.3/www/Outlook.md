*This page should have a lot more information about Outlook.com. For
now it's just a collection of notes.*

As of Oct 2013, outlook.com fails to find messages using a date range
search - start \<= msg \<= end.
