IMAP Store
==========

The IMAP Store supports reading mail from mail servers using the IMAP
protocol. The primary documentation for the IMAP Store is in the
javadocs for the
[com.sun.mail.imap package](docs/api/com/sun/mail/imap/package-summary.html).
Be sure to read the package level javadocs, which describe the
properties you can set, as well as the javadocs for the individual
classes in the package.

This page is currently a placeholder for more information about the IMAP Store.
